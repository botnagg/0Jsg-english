let words = [
    {
        word: "DICTIONARY",
        hint: "Listing of lexemes from the lexicon of one or more specific languages."
    },
    {
        word:"SHADOW",
        hint:"Dark area where light from a light source is blocked by an object."
    },
    {
        word:"LOVE",
        hint:"Range of strong and positive emotional and mental states, from the most sublime virtue or good habit, the deepest interpersonal affection, to the simplest pleasure."
    },
    {
        word:"GOD",
        hint:"Supreme being."
    },
    {
        word:"DESK",
        hint:"Piece of furniture with a flat table-style work surface used in a school, office, home or the like for academic, professional or domestic activities such as reading, writing, or using equipment such as a computer."
    },
    {
        word:"NIGHTMARE",
        hint:"Unpleasant dream."
    },
    {
        word:"BIRD",
        hint:"Warm-blooded vertebrates constituting the class Aves."
    },
    {
        word:"CHALKBOARD",
        hint:"Reusable writing surface on which text or drawings are made with sticks."
    },
]